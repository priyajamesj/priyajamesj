# rest-api-automation
REST Assured + TestNG automation framework for REST API.

# Installation

### Requirement

* JRE
* Maven

### Build and run Sanity tests

* mvn -Psanity clean test -Duname=TestUser -Dpwd=Qwer12
